const API_URL = "https://jsonplaceholder.typicode.com/users"; // For testing only

async function getStudent() {
    const id = document.getElementById("studentId").value;
    if (!id) return alert("Please enter the student ID");
    
    try {
        const res = await fetch(`${API_URL}/${id}`);
        const data = await res.json();
        alert(`Student name: ${data.name}`);
    } catch (err) {
        alert("Student not found");
    }
}

async function addStudent() {
    const id = document.getElementById("studentId").value;
    const name = document.getElementById("studentName").value;
    if (!id || !name) return alert("Please fill in all fields");

    const student = {
        id: id,
        name: name,
        username: name.toLowerCase().replace(" ", ""),
        email: `${name.toLowerCase()}@example.com`
    };

    try {
        const res = await fetch(API_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(student)
        });

        const data = await res.json();
        alert(`Student added: ${data.name}`);
        displayStudents();
    } catch (err) {
        alert("Failed to add student");
    }
}

async function editStudent(id) {
    const newName = prompt("Enter new name:");
    if (!newName) return;

    try {
        const res = await fetch(`${API_URL}/${id}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ name: newName })
        });

        const data = await res.json();
        alert(`Student updated: ${data.name}`);
        displayStudents();
    } catch (err) {
        alert("Failed to update student");
    }
}

async function deleteStudent(id) {
    const confirmDelete = confirm("Are you sure you want to delete this student?");
    if (!confirmDelete) return;

    try {
        await fetch(`${API_URL}/${id}`, {
            method: "DELETE"
        });
        alert(`Student deleted (fake - API doesn't store it)`);
        displayStudents();
    } catch (err) {
        alert("Failed to delete student");
    }
}

async function displayStudents() {
    const list = document.getElementById("students");
    list.innerHTML = "";

    try {
        const res = await fetch(API_URL);
        const students = await res.json();

        students.forEach(student => {
            const li = document.createElement("li");
            li.textContent = `ID: ${student.id} - Name: ${student.name} `;

            // Edit button
            const editBtn = document.createElement("button");
            editBtn.textContent = "Edit";
            editBtn.onclick = () => editStudent(student.id);
            li.appendChild(editBtn);

            // Delete button
            const deleteBtn = document.createElement("button");
            deleteBtn.textContent = "Delete";
            deleteBtn.onclick = () => deleteStudent(student.id);
            li.appendChild(deleteBtn);

            list.appendChild(li);
        });
    } catch (err) {
        list.innerHTML = "Error loading student list";
    }
}

window.onload = displayStudents;